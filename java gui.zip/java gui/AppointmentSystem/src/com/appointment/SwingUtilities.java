package com.appointment;

public class SwingUtilities {

}
